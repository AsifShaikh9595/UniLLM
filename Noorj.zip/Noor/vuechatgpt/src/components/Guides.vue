<template>
  <div
    class="react-scroll-to-bottom--css-ryzwt-1n7m0yu relative bg-white dark:bg-gray-800 min-h-screen flex items-center justify-center"
  >
    <!-- Main Content -->
    <div class="flex flex-col items-center text-sm text-center">
      <!-- Logo -->
      <div class="mb-4">
        <img
          src="../assets/favicon_old.png"
          alt="University GPT Logo"
          class="w-16 h-16 rounded-full shadow-lg"
        />
      </div>

      <!-- Title -->
      <h1 class="text-4xl font-semibold mb-6 text-gray-800 dark:text-gray-100">
        University GPT
      </h1>

      <!-- Buttons -->
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full max-w-3xl">
        <button
          class="card w-full bg-gray-50 dark:bg-white/5 p-4 rounded-md hover:bg-gray-200 dark:hover:bg-gray-900"
        >
          Enrolment Analysis
        </button>
        <button
          class="card w-full bg-gray-50 dark:bg-white/5 p-4 rounded-md hover:bg-gray-200 dark:hover:bg-gray-900"
        >
          Student Demographics
        </button>
        <button
          class="card w-full bg-gray-50 text-gray-800 dark:bg-white/5 p-4 rounded-md hover:bg-gray-200 dark:hover:bg-gray-900"
        >
          College Performance Review
        </button>
        <button
          class="card w-full bg-gray-50 text-gray-800 dark:bg-white/5 p-4 rounded-md hover:bg-gray-200 dark:hover:bg-gray-900"
        >
          Pre-Exam Status Check
        </button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "UniversityPage",
};
</script>

<style scoped>
.card {
  min-height: 100px;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  box-sizing: border-box;
}
</style>
