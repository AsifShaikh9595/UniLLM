<script setup>
import TheWelcome from '../components/TheWelcome.vue'
</script>

<template>
  <main>
    <input type="text" placeholder="Ask any question..">
  </main>
</template>
